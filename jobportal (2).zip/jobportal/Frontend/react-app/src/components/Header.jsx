import React, { useEffect, useState, useRef } from "react";
import AOS from "aos";
import { Link } from "react-router-dom";

const Header = () => {
  const [showPreloader, setShowPreloader] = useState(true); // Preloader state
  const [showBackToTop, setShowBackToTop] = useState(false); // Back to top visibility state
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false); // Mobile navigation state

  const headerRef = useRef(null); // Ref for the header element
  const navbarLinksRef = useRef([]); // Ref for storing navbar links

  const handleNavToggle = () => {
    setIsMobileNavOpen(!isMobileNavOpen); // Toggle mobile navigation
  };

  useEffect(() => {
    // Handle Preloader
    const handleLoad = () => {
      setShowPreloader(false);
    };
    window.addEventListener("load", handleLoad);

    // Navbar link active state on scroll
    const handleScroll = () => {
      const position = window.scrollY + 200;
      navbarLinksRef.current.forEach((navbarLink) => {
        const section = document.querySelector(navbarLink.getAttribute("href"));
        if (!section) return;
        if (
          position >= section.offsetTop &&
          position <= section.offsetTop + section.offsetHeight
        ) {
          navbarLink.classList.add("active");
        } else {
          navbarLink.classList.remove("active");
        }
      });

      // Back to Top button visibility
      setShowBackToTop(window.scrollY > 100);

      // Toggle .header-scrolled class when page is scrolled
      if (headerRef.current) {
        if (window.scrollY > 100) {
          headerRef.current.classList.add("header-scrolled");
        } else {
          headerRef.current.classList.remove("header-scrolled");
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    window.addEventListener("load", handleScroll);

    AOS.init({
      duration: 1000,
      easing: "ease-in-out",
      once: true,
      mirror: false,
    });

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("load", handleLoad);
    };
  }, []);

  return (
    <>
      <header id="header" className="fixed-top" ref={headerRef}>
        <div className="container d-flex align-items-center">
          <h1 className="logo me-auto">
            <Link to="/">TeamgridMatch</Link>
          </h1>

          <nav
            id="navbar"
            className={`navbar ${isMobileNavOpen ? "navbar-mobile" : ""}`}
          >
            <i
              className={`bi ${
                isMobileNavOpen ? "bi-x" : "bi-list"
              } mobile-nav-toggle`}
              onClick={handleNavToggle}
            ></i>

            <ul className={`navbar-menu ${isMobileNavOpen ? "show" : ""}`}>
              <li>
                <Link className="nav-link scrollto" to="/home">
                  Home
                </Link>
              </li>
              <li>
                <Link className="nav-link scrollto" to="/about">
                  About
                </Link>
              </li>
              <li>
                <Link className="nav-link scrollto" to="/services">
                  Services
                </Link>
              </li>
              <li>
                <Link className="nav-link scrollto" to="/team">
                  Team
                </Link>
              </li>

              <li class="dropdown">
                <a href="#">
                  <span>Jobs</span> <i class="bi bi-chevron-down"></i>
                </a>
                <ul>
                  <li class="dropdown">
                    <a href="#">
                      <span>Top Location</span>{" "}
                      <i class="bi bi-chevron-right"></i>
                    </a>
                    <ul>
                      <li>
                        <a href="#">Work From Home</a>
                      </li>
                      <li>
                        <a href="#">New York</a>
                      </li>
                      <li>
                        <a href="#">San Francisco</a>
                      </li>
                      <li>
                        <a href="#">London</a>
                      </li>
                      <li>
                        <a href="#">Remote Jobs</a>
                      </li>
                    </ul>
                  </li>
                  <li class="dropdown">
                    <a href="#">
                      <span>Top Categories</span>{" "}
                      <i class="bi bi-chevron-right"></i>
                    </a>
                    <ul>
                      <li>
                        <a href="#">Fresher Jobs</a>
                      </li>
                      <li>
                        <a href="#">Experienced Jobs</a>
                      </li>
                      <li>
                        <a href="#">IT Jobs</a>
                      </li>
                      <li>
                        <a href="#">Marketing Jobs</a>
                      </li>
                      <li>
                        <a href="#">Finance Jobs</a>
                      </li>
                    </ul>
                  </li>
                  <li>
                    <a href="#">Drop Down 2</a>
                  </li>
                  <li>
                    <a href="#">Drop Down 3</a>
                  </li>
                  <li>
                    <a href="#">Drop Down 4</a>
                  </li>
                </ul>
              </li>

              <li>
                <Link className="nav-link scrollto" to="/wantjob">
                  Want A Job
                </Link>
              </li>
              <li>
                <Link className="nav-link scrollto" to="/postjob">
                  Post A Job
                </Link>
              </li>
              <li className="dropdown">
                <Link className="getstarted scrollto" to="/login">
                  Login
                </Link>
                <ul>
                  <li>
                    <a href="/">For Candidate</a>
                  </li>
                  <li>
                    <a href="/">For Employers</a>
                  </li>
                </ul>
              </li>
            </ul>
          </nav>
        </div>
      </header>
    </>
  );
};

export default Header;
