export const API_BASE_URL = "http://localhost:8080/job/";
export const FILE_BASE_URL = "http://localhost:8080/";