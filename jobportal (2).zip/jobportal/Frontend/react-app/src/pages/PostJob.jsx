import React, { useState } from "react";
import axios from "axios";
import { API_BASE_URL } from "../constant/Env";
import "./PostJob.css";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const PostJob = () => {
  const [formData, setFormData] = useState({
    title: "",
    companyName: "",
    salaryRange: "",
    location: { city: "", country: "" }, // Nested object for location
    jobType: "",
    description: "",
    responsibilities: [], // Array for responsibilities
    skills: [], // Array for skills
    experienceLevel: "",
    contactEmail: "",
    websiteUrl: "",
  });

  const [companyLogo, setCompanyLogo] = useState(null); // File state for company logo
  const [inputValue, setInputValue] = useState(""); // For handling user input for skills and responsibilities
  const [responsibilityValue, setResponsibilityValue] = useState(""); // Input for responsibilities
  const navigate = useNavigate();

  // Handle form input changes for nested objects like location
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "city" || name === "country") {
      setFormData((prevData) => ({
        ...prevData,
        location: { ...prevData.location, [name]: value }, // Update nested location field
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };
  console.log(formData,"formdata")
  // Handle file input change (company logo)
  const handleFileChange = (e) => {
    setCompanyLogo(e.target.files[0]); // Capture the file object
  };

  // Reset form fields and file input
  const handleReset = () => {
    setFormData({
      title: "",
      companyName: "",
      salaryRange: "",
      location: { city: "", country: "" },
      jobType: "",
      description: "",
      responsibilities: [],
      skills: [],
      experienceLevel: "",
      contactEmail: "",
      websiteUrl: "",
    });
    setCompanyLogo(null); // Reset the file input
    setInputValue("");
    setResponsibilityValue("");
  };

  // Handle adding skills
  const handleSkillInput = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      const newSkill = inputValue.trim();
      if (newSkill && !formData.skills.includes(newSkill)) {
        setFormData((prevData) => ({
          ...prevData,
          skills: [...prevData.skills, newSkill],
        }));
      }
      setInputValue(""); // Clear input after adding skill
    }
  };

  // Handle adding responsibilities
  const handleResponsibilityInput = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      const newResponsibility = responsibilityValue.trim();
      if (newResponsibility && !formData.responsibilities.includes(newResponsibility)) {
        setFormData((prevData) => ({
          ...prevData,
          responsibilities: [...prevData.responsibilities, newResponsibility],
        }));
        setResponsibilityValue(""); // Clear input after adding responsibility
      } else {
        // Optional: Provide feedback if the responsibility is invalid
        toast.error("Responsibility is either empty or already added.");
      }
    }
  };

  // Remove a skill from the list
  const removeSkill = (skillIndex) => {
    setFormData((prevData) => ({
      ...prevData,
      skills: prevData.skills.filter((_, index) => index !== skillIndex),
    }));
  };

  // Remove a responsibility from the list
  const removeResponsibility = (index) => {
    setFormData((prevData) => ({
      ...prevData,
      responsibilities: prevData.responsibilities.filter(
        (_, idx) => idx !== index
      ),
    }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Prepare form data for submission
    let jobFormData = new FormData();

    // Loop through the form data and append fields to FormData
    Object.keys(formData).forEach((key) => {
      if (Array.isArray(formData[key])) {
        formData[key].forEach((item) => jobFormData.append(`${key}[]`, item)); // Append arrays like skills and responsibilities
      } else if (typeof formData[key] === "object" && formData[key] !== null) {
        // For nested objects like location, flatten the object and append
        if (key === "location") {
          jobFormData.append("location.city", formData.location.city);
          jobFormData.append("location.country", formData.location.country);
        }
      } else {
        jobFormData.append(key, formData[key]); // Append simple fields
      }
    });

    // Append the file if selected
    if (companyLogo) {
      jobFormData.append("companyLogo", companyLogo); // Append the file
    }

    let config = {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    };

    try {
      const response = await axios.post(
        API_BASE_URL + "job/post",
        jobFormData,
        config
      );
      toast.success("Job posted successfully!");
      console.log("Job posted successfully!", response.data);
      handleReset(); // Reset the form after successful submission
      navigate("/wantjob"); // Navigate to job list after posting
    } catch (error) {
      toast.error("There was an error saving your data. Please try again.");
      console.error("Failed to post the job. Please try again.", error);
    }
  };

  return (
    <>
      <div style={{ height: "40px" }}></div>
      <section id="post-job-section" className="section-bg">
        <div className="section-title">
          <h2>POST A JOB</h2>
        </div>
        <div className="container" data-aos="fade-up">
          <div className="post-job-container">
            <h1>Post a Job</h1>
            <form className="post-job-form" onSubmit={handleSubmit}>
              {/* Job title */}
              {/* <label>
                Job Title:
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  required
                />
              </label> */}

              {/* Company details */}
              <div className="form-group">
                <label>
                  Company Name:
                  <input
                    type="text"
                    name="companyName"
                    value={formData.companyName}
                    onChange={handleChange}
                    required
                  />
                </label>
                <label>
                  Company Logo:
                  <input
                    type="file"
                    name="companyLogo"
                    onChange={handleFileChange}
                    accept="image/*"
                  />
                </label>
              </div>

              {/* Location */}
              <div className="form-group">
                <label>
                  City:
                  <input
                    type="text"
                    name="city"
                    value={formData.location.city}
                    onChange={handleChange}
                    required
                  />
                </label>
                <label>
                  Country:
                  <input
                    type="text"
                    name="country"
                    value={formData.location.country}
                    onChange={handleChange}
                    required
                  />
                </label>
              </div>

              {/* Job details */}
              <div className="form-group">
                <label>
                  Job Type:
                  <select
                    name="jobType"
                    value={formData.jobType}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Job Type</option>
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                    <option value="Contract">Contract</option>
                    <option value="Temporary">Temporary</option>
                    <option value="Internship">Internship</option>
                  </select>
                </label>
                <label>
                  Salary Range:
                  <input
                    type="text"
                    name="salaryRange"
                    value={formData.salaryRange}
                    onChange={handleChange}
                    required
                  />
                </label>
              </div>

              {/* Experience level and contact */}
              <div className="form-group">
                <label>
                  Experience Level:
                  <select
                    name="experienceLevel"
                    value={formData.experienceLevel}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Experience Level</option>
                    <option value="0-1yr">0-1 year</option>
                    <option value="1-3yr">1-3 years</option>
                    <option value="3-5yr">3-5 years</option>
                    <option value="5-8yr">5-8 years</option>
                    <option value="8above">8+ years</option>
                  </select>
                </label>
                <label>
                  Contact Email:
                  <input
                    type="email"
                    name="contactEmail"
                    value={formData.contactEmail}
                    onChange={handleChange}
                    required
                  />
                </label>
              </div>

              {/* Responsibilities */}
              {/* <label>
                Responsibilities:
                <div className="skills-input-wrapper">
                  {formData.responsibilities.map((responsibility, index) => (
                    <div key={index} className="skill-chip">
                      {responsibility}
                      <button
                        type="button"
                        className="remove-skill-btn"
                        onClick={() => removeResponsibility(index)}
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                  <input
                    type="text"
                    value={responsibilityValue}
                    onChange={(e) => setResponsibilityValue(e.target.value)}
                    onKeyDown={handleResponsibilityInput}
                    placeholder="Type a responsibility and press Enter"
                  />
                </div>
              </label> */}

              {/* Skills */}
              {/* <label>
                Skills:
                <div className="skills-input-wrapper">
                  {formData.skills.map((skill, index) => (
                    <div key={index} className="skill-chip">
                      {skill}
                      <button
                        type="button"
                        className="remove-skill-btn"
                        onClick={() => removeSkill(index)} // Use the index to uniquely identify the skill
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleSkillInput}
                    placeholder="Type a skill and press Enter"
                  />
                </div>
              </label> */}

              {/* Job description */}
              <label>
                Description:
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  required
                />
              </label>

              {/* Form actions */}
              <div className="form-actions">
                <button type="submit" className="submit-btn">
                  <i className="fas fa-check"></i> Post Job
                </button>
                <button
                  type="button"
                  className="reset-btn"
                  onClick={handleReset}
                >
                  <i className="fas fa-redo-alt"></i> Reset
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default PostJob;
