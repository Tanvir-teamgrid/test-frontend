import { useEffect, useState } from "react";
import axios from "axios";
import { API_BASE_URL, FILE_BASE_URL } from "../constant/Env";
import "./WantJob.css";

const WantJob = () => {
  const [jobData, setJobData] = useState([]);
  const [selectedJob, setSelectedJob] = useState(null); // State to track the selected job

  // Fetch the job list from the API
  const getJobList = async () => {
    try {
      const response = await axios.get(API_BASE_URL + "job/list");
      console.log("Fetched Job Data: ", response); // Log the data
      setJobData(response.data);
    } catch (error) {
      console.error("Error fetching job list:", error);
    }
  };

  useEffect(() => {
    getJobList();
  }, []);

  // Handle job card click to show details in the right-side panel
  const handleJobClick = (job) => {
    setSelectedJob(job); // Set the clicked job as the selected job
  };

  return (
    <>
      <div style={{ height: "40px" }}></div>
      <section id="jobs" className="section-bg">
        <div className="container" data-aos="fade-up">
          <div className="section-title">
            <h2>JOBS</h2>
            <p>
              Be part of a project developer team that values precision,
              creativity, and teamwork, driving forward with passion to deliver
              successful and cutting-edge projects.
            </p>
          </div>
          <div className="job-page-container">
            {/* Left side: Job list */}
            <div className="job-list-container">
              <div className="job-list" data-aos="zoom-in" data-aos-delay="100">
                {jobData.length > 0 ? (
                  jobData.map((job) => (
                    <div
                      key={job._id}
                      className={`job-card ${
                        selectedJob?._id === job._id ? "active" : ""
                      }`}
                      onClick={() => handleJobClick(job)}
                    >
                      <div className="job-card-header">
                        <div className="job-title">{job.title}</div>
                        <div className="company-logo">
                          <img
                            src={
                              job.companyLogo
                                ? FILE_BASE_URL +
                                  "company-logo/" +
                                  job.companyLogo
                                : "assets/images/no-image.png"
                            }
                            alt={job.companyName || "Company Logo"}
                          />
                        </div>
                      </div>
                      <div className="job-card-info">
                        <div className="job-criteria">
                          <div className="criteria-item">
                            <span className="criteria-icon">💼</span>
                            <span className="criteria-value">
                              {job.experienceLevel || "N/A"}
                            </span>
                          </div>
                          <div className="criteria-item">
                            <span className="criteria-icon">₹</span>
                            <span className="criteria-value">
                              {job.salaryRange || "Not disclosed"}
                            </span>
                          </div>
                          <div className="criteria-item">
                            <span className="criteria-icon">📍</span>
                            <span className="criteria-value">
                              {job.location?.city || "Unknown"}, {job.location?.country || "Unknown"}
                            </span>
                          </div>
                          <div className="criteria-item">
                            <span className="criteria-icon">👥</span>
                            <span className="criteria-value">
                              {job.vacancies || "N/A"} Vacancies
                            </span>
                          </div>
                        </div>
                        <div className="job-description">
                          <span className="description-text">
                            {job.description?.substring(0, 100) ||
                              "No description available"}
                          </span>
                        </div>
                        {/* <div className="job-skills">
                          {job.skills && job.skills.length > 0 ? (
                            job.skills.map((skill, index) => (
                              <button key={index} className="job-skill-item">
                                <span>{skill}</span>
                              </button>
                            ))
                          ) : (
                            <span className="skills-text">
                              No skills listed
                            </span>
                          )}
                        </div> */}
                      </div>
                      <div className="job-card-footer">
                        <div className="job-posted">
                          {new Date(job.postedDate).toLocaleDateString() || "Unknown"}
                        </div>
                        <div className="job-actions">
                          <button className="save-button">Save</button>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p>No jobs available.</p>
                )}
              </div>
            </div>

            {/* Right side: Job details */}
            <div
              className={`job-details-container ${selectedJob ? "active" : ""}`}
            >
              {selectedJob ? (
                <div className="job-details-panel">
                  <h2>{selectedJob.title}</h2>
                  <p>
                    <strong>Company:</strong> {selectedJob.companyName}
                  </p>
                  <p>
                    <strong>Location:</strong> {selectedJob.location?.city}, {selectedJob.location?.country}
                  </p>
                  <p>
                    <strong>Salary Range:</strong> {selectedJob.salaryRange}
                  </p>
                  <p>
                    <strong>Job Type:</strong> {selectedJob.jobType}
                  </p>
                  <p>
                    <strong>Description:</strong> {selectedJob.description}
                  </p>
                  <p>
                    <strong>Responsibilities:</strong>{" "}
                    {selectedJob.responsibilities?.join(", ")}
                  </p>
                  <p>
                    <strong>Skills:</strong> {selectedJob.skills?.join(", ")}
                  </p>
                  <p>
                    <strong>Experience Level:</strong>{" "}
                    {selectedJob.experienceLevel}
                  </p>
                  <p>
                    <strong>Vacancies:</strong> {selectedJob.vacancies}
                  </p>
                  <p>
                    <strong>Contact Email:</strong> {selectedJob.contactEmail}
                  </p>
                  <p>
                    <strong>Website:</strong>
                    <a
                      href={selectedJob.websiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {selectedJob.websiteUrl}
                    </a>
                  </p>
                </div>
              ) : (
                <div className="no-job-selected">
                  <p>Please select a job to view the details.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default WantJob;
