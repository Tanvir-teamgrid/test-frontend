const PrivacyPolicy= () => {
    return (
        <>
            <h4>This is the Privacy Policy</h4>
        </>
    )
}

export default PrivacyPolicy;