import { BrowserRouter,Navigate, Routes, Route } from 'react-router-dom';
import './App.css';
import About from './pages/About';
import Home from './pages/Home';
import PostJob from './pages/PostJob';
import WantJob from './pages/WantJob';
import Header from './components/Header';
import Footer from './components/Footer';
import Services from './pages/Services';
import Team from './pages/Team';
import PrivacyPolicy from './cms/PrivacyPolicy';

function App() {
  return (
    <div className='App'>
      <BrowserRouter>
        <Header/> 
        <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/wantjob" element={<WantJob />} />
          <Route path="/services" element={<Services />} />
          <Route path='/team' element={<Team />} />
          <Route path="/postjob" element={<PostJob />} />
          <Route path='*' element={<Navigate to = '/home'/>}></Route>
          <Route path='/privacypolicy' element={<PrivacyPolicy />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
